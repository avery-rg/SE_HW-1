To launch "Twitter" follow these steps:

1.  Launch index.js via node (I used nodemon)
2.  Go to http://localhost:3000
3.  Use the following buttons to post/find/edit/delete different tweets
4.  Make sure to have no spaces in the text ox or it won't work

[Make Post]
Fill out the Text box and the Tweet ID box then hit post when finished.

[Find Post]
Enter the Tweet ID into the text box, but make sure not to have any spaces or it will not work. Then hit find.

[Change Name]
Enter the name of the person whose screen name will change (don't enter the screen name). Enter the new screen name and hit change.

[Delete Post]
Enter the Tweet Id of the post you wish to delete, but make sure not to have any spaces or it will not work. Then hit delete.
